"""Document chunker."""
